=== Sellix Pay ===
Contributors: sellix, hdhingra 
Tags: crypto,paypal, sellix-pay, payment-gateway, trust wallet, bitcoin, cryptocurrency, crypto wallet, walletconnect
Requires at least: 4.9
Tested up to: 6.0.1
Stable tag: 1.1
Author URI: https://sellix.io/
Author:   Sellix io
Version: 1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Requires PHP: 7.4

Accept payments via purchase order.

== Description ==

Accept all type of payments via purchase order.